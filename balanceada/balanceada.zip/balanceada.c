#include <stdio.h>
#include <stdlib.h>
#include <stdbool.h>
#include "item.h"
#include "Pilha.h"

bool balanceada(char *sequencia){
    PILHA *pilha;
    char letra;
    pilha = pilha_criar();

    letra = sequencia[0];
    while(letra != 0){
        if(letra == '(' || letra == '{' || letra == '['){
            pilha_empilhar(pilha, item_criar(letra));
        }else if((letra == ')' && !pilha_vazia(pilha)) || (letra == '}' && !pilha_vazia(pilha)) || (letra == ']' && !pilha_vazia(pilha))){
            if((letra == ')' && item_get_chave(pilha_topo(pilha)) == '(') || (letra == '}' && item_get_chave(pilha_topo(pilha)) == '{') || (letra == ']' && item_get_chave(pilha_topo(pilha)) == '[')){
                pilha_desempilhar(pilha);
            }else return false;
        }else return false;
        sequencia++;
        letra = *sequencia;
    }

    if(pilha_vazia(pilha)) return true;
    else return false;
}